<?php
require 'config.php';
require 'functions.php';
checkAuth('admin');
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    verifyCsrf($_POST['csrf_token']);
    $stmt = $pdo->prepare('UPDATE company_info SET name = ?, address = ?, phone = ? WHERE id = 1');
    $stmt->execute([trim($_POST['name']), trim($_POST['address']), trim($_POST['phone'])]);
    setFlash('success', 'บันทึกข้อมูลเรียบร้อยแล้ว');
    header('Location: company.php');
    exit;
}
$c = $pdo->query('SELECT * FROM company_info WHERE id = 1')->fetch();
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><title>ตั้งค่าบริษัท</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<a href="index.php" class="btn">กลับ</a>
<div class="card" style="margin-top: 20px;">
<h2>ตั้งค่าบริษัท (Company Info)</h2>
<?php echo getFlash(); ?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?php echo e($_SESSION['csrf_token']); ?>">
<label>ชื่อบริษัท:</label>
<input type="text" name="name" value="<?php echo e($c['name'] ?? ''); ?>" required maxlength="100">
<label>ที่อยู่:</label>
<textarea name="address" required rows="4"><?php echo e($c['address'] ?? ''); ?></textarea>
<label>เบอร์โทรศัพท์:</label>
<input type="text" name="phone" value="<?php echo e($c['phone'] ?? ''); ?>" required maxlength="20">
<button type="submit" class="btn">บันทึกการเปลี่ยนแปลง</button>
</form>
</div>
</div>
</body>
</html>