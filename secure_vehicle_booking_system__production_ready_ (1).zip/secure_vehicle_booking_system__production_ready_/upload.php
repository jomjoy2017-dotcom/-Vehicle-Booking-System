<?php
require 'config.php';
require 'functions.php';
checkAuth();
header('Content-Type: application/json');
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        echo json_encode(['status' => 'error', 'message' => 'CSRF verification failed']); exit;
    }
    $targetDir = __DIR__ . '/uploads/';
    if(!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }
    $file = $_FILES['file'];
    if($file['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['status' => 'error', 'message' => 'Upload error']); exit;
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    $allowed_mimes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'video/mp4' => 'mp4'
    ];
    if(!array_key_exists($mime, $allowed_mimes)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid file type']); exit;
    }
    $extension = $allowed_mimes[$mime];
    $fileName = bin2hex(random_bytes(16)) . '.' . $extension;
    $targetFilePath = $targetDir . $fileName;
    if(move_uploaded_file($file['tmp_name'], $targetFilePath)) {
        echo json_encode(['status' => 'success', 'path' => 'uploads/' . $fileName]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to move file']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'No file uploaded']);
}
?>