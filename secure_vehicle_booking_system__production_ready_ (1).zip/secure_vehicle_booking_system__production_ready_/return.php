<?php
require 'config.php';
require 'functions.php';
checkAuth();
if(isset($_POST['return_id']) && isset($_POST['csrf_token'])) {
    verifyCsrf($_POST['csrf_token']);
    $stmt = $pdo->prepare("UPDATE bookings SET return_time = NOW(), status = 'returned', recorded_by = ? WHERE id = ? AND status = 'booked'");
    if($stmt->execute([$_SESSION['user_id'], $_POST['return_id']])) {
        setFlash('success', 'บันทึกการกลับเรียบร้อย (Return recorded)');
    }
}
$results = [];
if(isset($_GET['search']) && trim($_GET['search']) !== '') {
    $q = '%' . trim($_GET['search']) . '%';
    $stmt = $pdo->prepare('SELECT b.*, v.license_plate, u.fullname as staff_name FROM bookings b LEFT JOIN vehicles v ON b.vehicle_id = v.id LEFT JOIN users u ON b.recorded_by = u.id WHERE b.booking_code LIKE ? OR b.fullname LIKE ? ORDER BY b.id DESC');
    $stmt->execute([$q, $q]);
    $results = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><title>บันทึกการคืนรถ</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container no-print">
<a href="index.php" class="btn">กลับ (Back)</a>
<div class="card" style="margin-top: 20px;">
<h2>หน้าบันทึกตอนกลับ / ค้นหาประวัติ</h2>
<?php echo getFlash(); ?>
<form method="get">
<div style="display:flex; gap:10px;">
<input type="text" name="search" placeholder="ค้นหาจากรหัสจอง หรือ ชื่อนามสกุล" value="<?php echo e($_GET['search'] ?? ''); ?>" style="flex:1" required>
<button type="submit" class="btn">ค้นหา</button>
<button type="button" class="btn" onclick="window.print()">ปริ้น PDF</button>
</div>
</form>
</div>
</div>
<?php if(!empty($results)): ?>
<div class="container">
<div class="card">
<h3>ผลการค้นหา (Search Results)</h3>
<div class="table-responsive">
<table>
<tr><th>รหัส</th><th>ชื่อ</th><th>ทะเบียน</th><th>เวลาเริ่ม</th><th>เวลาออก(คืน)</th><th>ผู้บันทึก</th><th class="no-print">จัดการ</th></tr>
<?php foreach($results as $r): ?>
<tr>
<td><?php echo e($r['booking_code']); ?></td>
<td><?php echo e($r['fullname']); ?></td>
<td><?php echo e($r['license_plate']); ?></td>
<td><?php echo e($r['start_time']); ?></td>
<td><?php echo e($r['return_time'] ?? '-'); ?></td>
<td><?php echo e($r['staff_name'] ?? '-'); ?></td>
<td class="no-print">
<?php if($r['status'] == 'booked'): ?>
<form method="post" style="display:inline;">
<input type="hidden" name="csrf_token" value="<?php echo e($_SESSION['csrf_token']); ?>">
<input type="hidden" name="return_id" value="<?php echo e($r['id']); ?>">
<button type="submit" class="btn btn-success" onclick="return confirm('ยืนยันบันทึกการคืนรถ?');">บันทึกเข้ามาแล้ว</button>
</form>
<?php else: ?>
<span style="color:#16a34a;">คืนแล้ว</span>
<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
</table>
</div>
</div>
</div>
<?php endif; ?>
</body>
</html>