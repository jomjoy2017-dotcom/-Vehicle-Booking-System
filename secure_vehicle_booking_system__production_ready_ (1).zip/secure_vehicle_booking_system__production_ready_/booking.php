<?php
require 'config.php';
require 'functions.php';
checkAuth();
$vehicles = $pdo->query("SELECT * FROM vehicles WHERE status = 'active' AND is_deleted = 0")->fetchAll();
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    verifyCsrf($_POST['csrf_token']);
    $vid = $_POST['vehicle_id'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $phone = preg_replace('/[^0-9]/', '', $_POST['phone']);
    $fullname = mb_substr(trim($_POST['fullname']), 0, 100);
    if(strlen($phone) < 9 || strlen($phone) > 10) {
        setFlash('error', 'เบอร์โทรศัพท์ต้องเป็นตัวเลข 9-10 หลัก');
    } elseif (strtotime($end_time) <= strtotime($start_time)) {
        setFlash('error', 'เวลาสิ้นสุดต้องมากกว่าเวลาเริ่มใช้งาน');
    } else {
        try {
            $pdo->beginTransaction();
            $check = $pdo->prepare("SELECT id FROM bookings WHERE vehicle_id = ? AND status = 'booked' AND start_time < ? AND end_time > ? FOR UPDATE");
            $check->execute([$vid, $end_time, $start_time]);
            if($check->rowCount() > 0) {
                setFlash('error', 'รถคันนี้มีการจองในช่วงเวลาดังกล่าวแล้ว');
                $pdo->rollBack();
            } else {
                $bcode = generateCode($pdo, 'BK-', 'bookings');
                $stmt = $pdo->prepare('INSERT INTO bookings (booking_code, user_id, fullname, vehicle_id, department, phone, usage_details, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
                if($stmt->execute([$bcode, $_SESSION['user_id'], $fullname, $vid, $_POST['department'], $phone, $_POST['usage_details'], $start_time, $end_time])) {
                    setFlash('success', "จองสำเร็จ! Code: $bcode");
                    $pdo->commit();
                } else {
                    $pdo->rollBack();
                    setFlash('error', 'เกิดข้อผิดพลาด กรุณาลองใหม่');
                }
            }
        } catch (Exception $e) {
            $pdo->rollBack();
            error_log('Booking Error: ' . $e->getMessage());
            setFlash('error', 'ระบบขัดข้อง กรุณาลองใหม่');
        }
    }
}
$company = $pdo->query('SELECT * FROM company_info LIMIT 1')->fetch() ?: ['name'=>''];
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><title>บันทึกจองรถ</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="header no-print">
<div><strong><?php echo e($company['name']); ?></strong></div>
<nav><a href="index.php" class="btn">กลับ (Back)</a></nav>
</div>
<div class="container">
<div class="card" style="margin-top: 20px;">
<h2>หน้าบันทึกจองรถ</h2>
<?php echo getFlash(); ?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?php echo e($_SESSION['csrf_token']); ?>">
<label>ชื่อผู้จอง:</label>
<input type="text" name="fullname" value="<?php echo e($_SESSION['fullname']); ?>" readonly required maxlength="100">
<label>เลือกรถ:</label>
<select name="vehicle_id" required>
<option value="">เลือกประเภทรถ/ทะเบียน</option>
<?php foreach($vehicles as $v): ?>
<option value="<?php echo e($v['id']); ?>"><?php echo e($v['type'] . ' - ' . $v['license_plate']); ?></option>
<?php endforeach; ?>
</select>
<input type="text" name="department" placeholder="แผนก (Department)" required maxlength="100">
<input type="text" name="phone" placeholder="เบอร์โทรศัพท์ (Phone)" required pattern="[0-9]{9,10}">
<textarea name="usage_details" placeholder="รายละเอียดการใช้ (Usage Details)" required></textarea>
<div style="display:flex; gap:10px;">
<div style="flex:1"><label>เวลาเริ่มใช้งาน:</label><input type="datetime-local" name="start_time" required></div>
<div style="flex:1"><label>เวลาสิ้นสุด:</label><input type="datetime-local" name="end_time" required></div>
</div>
<button type="submit" class="btn" style="margin-top: 15px;">ยืนยันการจองรถ (Confirm Booking)</button>
</form>
</div>
</div>
</body>
</html>