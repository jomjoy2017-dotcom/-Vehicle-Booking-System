<?php
require '../config.php';
require '../functions.php';
checkAuth('admin');
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_vehicle'])) {
    verifyCsrf($_POST['csrf_token']);
    $stmt = $pdo->prepare("INSERT INTO vehicles (type, license_plate, status, is_deleted) VALUES (?, ?, 'active', 0)");
    if($stmt->execute([trim($_POST['type']), trim($_POST['license_plate'])])) {
        setFlash('success', 'เพิ่มรถสำเร็จ');
    }
}
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_vehicle'])) {
    verifyCsrf($_POST['csrf_token']);
    $stmt = $pdo->prepare('UPDATE vehicles SET is_deleted = 1 WHERE id = ?');
    if($stmt->execute([$_POST['delete_id']])) {
        setFlash('success', 'ลบรถออกจากระบบเรียบร้อย (Soft Delete)');
    }
}
$vehicles = $pdo->query('SELECT * FROM vehicles WHERE is_deleted = 0')->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><title>จัดการยานพาหนะ</title><link rel="stylesheet" href="../style.css"></head>
<body>
<div class="container">
<a href="../index.php" class="btn">กลับหน้าหลัก</a>
<div class="card" style="margin-top: 20px;">
<h2>เพิ่มข้อมูลรถ (Add Vehicle)</h2>
<?php echo getFlash(); ?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?php echo e($_SESSION['csrf_token']); ?>">
<select name="type" required>
<option value="car">รถยนต์ (Car)</option>
<option value="van">รถตู้ (Van)</option>
<option value="motorcycle">รถมอเตอร์ไซค์ (Motorcycle)</option>
</select>
<input type="text" name="license_plate" placeholder="ทะเบียนรถ (License Plate)" required maxlength="50">
<button type="submit" name="add_vehicle" class="btn">บันทึก</button>
</form>
</div>
<div class="card">
<h2>รายการรถทั้งหมด</h2>
<div class="table-responsive">
<table>
<tr><th>ID</th><th>Type</th><th>License Plate</th><th>Status</th><th>จัดการ</th></tr>
<?php foreach($vehicles as $v): ?>
<tr>
<td><?php echo e($v['id']); ?></td>
<td><?php echo e($v['type']); ?></td>
<td><?php echo e($v['license_plate']); ?></td>
<td><?php echo e($v['status']); ?></td>
<td>
<form method="post" style="display:inline;">
<input type="hidden" name="csrf_token" value="<?php echo e($_SESSION['csrf_token']); ?>">
<input type="hidden" name="delete_id" value="<?php echo e($v['id']); ?>">
<button type="submit" name="delete_vehicle" class="btn btn-danger" onclick="return confirm('ยืนยันการลบ?');">ลบ</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</table>
</div>
</div>
</div>
</body>
</html>