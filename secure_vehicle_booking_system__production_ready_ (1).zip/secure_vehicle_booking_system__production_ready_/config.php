<?php
date_default_timezone_set('Asia/Bangkok');
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/error.log');
session_start(['cookie_httponly' => true, 'cookie_secure' => isset($_SERVER['HTTPS']), 'use_strict_mode' => true, 'cookie_samesite' => 'Lax']);
define('DB_HOST', 'localhost');
define('DB_NAME', 'vehicle_booking');
define('DB_USER', 'root');
define('DB_PASS', '');
try {
    $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    error_log('DB Error: ' . $e->getMessage());
    header('HTTP/1.1 503 Service Unavailable');
    exit('System unavailable.');
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$lang = $_SESSION['lang'] ?? 'th';
if(isset($_GET['lang']) && in_array($_GET['lang'], ['th', 'en'])) {
    $lang = $_SESSION['lang'] = $_GET['lang'];
}
$dict = [
    'th' => ['app'=>'ระบบจองรถ', 'login'=>'เข้าสู่ระบบ', 'logout'=>'ออกจากระบบ', 'book'=>'จองรถ', 'return'=>'บันทึกตอนกลับ', 'history'=>'ประวัติ', 'search'=>'ค้นหา'],
    'en' => ['app'=>'Vehicle Booking', 'login'=>'Login', 'logout'=>'Logout', 'book'=>'Book', 'return'=>'Return', 'history'=>'History', 'search'=>'Search']
];
function t($k) { global $dict, $lang; return $dict[$lang][$k] ?? $k; }
?>