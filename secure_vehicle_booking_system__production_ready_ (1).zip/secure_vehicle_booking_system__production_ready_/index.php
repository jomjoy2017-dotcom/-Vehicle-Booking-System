<?php
require 'config.php';
require 'functions.php';
checkAuth();
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;
$total_stmt = $pdo->query('SELECT COUNT(*) FROM bookings');
$total_rows = $total_stmt->fetchColumn();
$total_pages = max(1, ceil($total_rows / $limit));
$stmt = $pdo->prepare('SELECT b.*, v.license_plate, v.type FROM bookings b JOIN vehicles v ON b.vehicle_id = v.id ORDER BY b.id DESC LIMIT :limit OFFSET :offset');
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$bookings = $stmt->fetchAll();
$company = $pdo->query('SELECT * FROM company_info LIMIT 1')->fetch() ?: ['name'=>'Company', 'address'=>'', 'phone'=>''];
?>
<!DOCTYPE html>
<html lang="<?php echo e($lang); ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="style.css">
<title><?php echo e(t('app')); ?></title>
</head>
<body>
<div class="header no-print">
<div><strong><?php echo e($company['name']); ?></strong><br><?php echo e($company['address']); ?> | โทร: <?php echo e($company['phone']); ?></div>
<div>สถานะ: <?php echo e($_SESSION['fullname']); ?> (<?php echo e($_SESSION['role']); ?>) | <a href="?lang=th">TH</a> | <a href="?lang=en">EN</a></div>
<nav>
<a href="index.php" class="btn"><?php echo e(t('history')); ?></a>
<a href="booking.php" class="btn"><?php echo e(t('book')); ?></a>
<a href="return.php" class="btn"><?php echo e(t('return')); ?></a>
<?php if($_SESSION['role'] === 'admin'): ?>
<a href="company.php" class="btn">Company</a>
<a href="admin/index.php" class="btn">Admin</a>
<?php endif; ?>
<a href="login.php?action=logout" class="btn btn-danger"><?php echo e(t('logout')); ?></a>
</nav>
</div>
<div class="container">
<?php echo getFlash(); ?>
<div class="card">
<h2>รายการจองล่าสุด (หน้า <?php echo e($page); ?> / <?php echo e($total_pages); ?>)</h2>
<div class="table-responsive">
<table>
<tr><th>รหัสการจอง</th><th>ผู้จอง</th><th>ประเภทรถ/ทะเบียน</th><th>เวลาเริ่มใช้งาน</th><th>เวลาสิ้นสุด</th><th>สถานะ</th></tr>
<?php foreach($bookings as $b): ?>
<tr>
<td><?php echo e($b['booking_code']); ?></td>
<td><?php echo e($b['fullname']); ?></td>
<td><?php echo e($b['type'] . ' / ' . $b['license_plate']); ?></td>
<td><?php echo e($b['start_time']); ?></td>
<td><?php echo e($b['end_time']); ?></td>
<td><span class="<?php echo $b['status'] == 'booked' ? 'alert-error' : 'alert-success'; ?>" style="padding: 2px 8px; border-radius: 4px;"><?php echo e($b['status']); ?></span></td>
</tr>
<?php endforeach; ?>
</table>
</div>
<div style="margin-top: 15px;">
<?php if($page > 1): ?><a href="?page=<?php echo $page - 1; ?>" class="btn">ก่อนหน้า</a><?php endif; ?>
<?php if($page < $total_pages): ?><a href="?page=<?php echo $page + 1; ?>" class="btn">ถัดไป</a><?php endif; ?>
</div>
</div>
</div>
</body>
</html>