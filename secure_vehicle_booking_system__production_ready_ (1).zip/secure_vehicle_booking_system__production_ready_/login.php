<?php
require 'config.php';
require 'functions.php';
if(isset($_GET['action']) && $_GET['action'] == 'logout') {
    session_unset(); session_destroy(); header('Location: login.php'); exit;
}
if(!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['last_attempt'] = time();
}
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    verifyCsrf($_POST['csrf_token']);
    if($_SESSION['login_attempts'] >= 5 && (time() - $_SESSION['last_attempt']) < 60) {
        setFlash('error', 'คุณพยายามเข้าสู่ระบบผิดพลาดหลายครั้ง กรุณารอ 1 นาที');
    } else {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
        $stmt->execute([$_POST['username']]);
        $user = $stmt->fetch();
        if($user && password_verify($_POST['password'], $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['fullname'] = $user['fullname'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['login_attempts'] = 0;
            header('Location: index.php'); exit;
        } else {
            $_SESSION['login_attempts']++;
            $_SESSION['last_attempt'] = time();
            sleep(1);
            setFlash('error', 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><title><?php echo e(t('login')); ?></title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container" style="max-width: 400px; margin-top: 100px;">
<div class="card">
<h2><?php echo e(t('login')); ?></h2>
<?php echo getFlash(); ?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?php echo e($_SESSION['csrf_token']); ?>">
<input type="text" name="username" placeholder="Username" required autocomplete="username">
<input type="password" name="password" placeholder="Password" required autocomplete="current-password">
<button type="submit" name="login" class="btn" style="width: 100%;">Login</button>
<div style="margin-top: 15px; text-align: center;"><a href="register.php">สมัครสมาชิก (Register)</a></div>
</form>
</div>
</div>
</body>
</html>