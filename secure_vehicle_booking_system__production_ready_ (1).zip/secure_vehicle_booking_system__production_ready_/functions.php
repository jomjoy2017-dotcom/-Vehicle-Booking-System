<?php
function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function generateCode($pdo, $prefix, $table) {
    $allowed_tables = ['users' => 'user_code', 'bookings' => 'booking_code'];
    if (!array_key_exists($table, $allowed_tables)) { error_log('Invalid table accessed.'); throw new Exception('Invalid table.'); }
    $stmt = $pdo->query('SELECT MAX(id) AS max_id FROM ' . $table);
    $row = $stmt->fetch();
    $next = ($row['max_id'] ?? 0) + 1;
    return $prefix . str_pad($next, 4, '0', STR_PAD_LEFT);
}
function checkAuth($role = null) {
    if(!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
    if($role && ($_SESSION['role'] ?? '') !== $role && ($_SESSION['role'] ?? '') !== 'admin') {
        http_response_code(403); die('Access Denied.');
    }
}
function verifyCsrf($token) {
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        error_log('CSRF Validation Failed for IP: ' . $_SERVER['REMOTE_ADDR']);
        die('CSRF Validation Failed.');
    }
}
function setFlash($type, $msg) { $_SESSION['flash'] = ['type' => $type, 'msg' => $msg]; }
function getFlash() {
    if(isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return "<div class='alert alert-{$f['type']}'>" . e($f['msg']) . "</div>";
    }
    return '';
}
?>