<?php
require 'config.php';
require 'functions.php';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    verifyCsrf($_POST['csrf_token']);
    $role = 'user';
    $user_code = generateCode($pdo, 'USR-', 'users');
    $hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
    try {
        $stmt = $pdo->prepare('INSERT INTO users (user_code, username, password, fullname, role) VALUES (?, ?, ?, ?, ?)');
        if($stmt->execute([$user_code, trim($_POST['username']), $hash, trim($_POST['fullname']), $role])) {
            setFlash('success', 'สมัครสมาชิกสำเร็จ กรุณาเข้าสู่ระบบ');
            header('Location: login.php');
            exit;
        }
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            setFlash('error', 'Username นี้มีในระบบแล้ว');
        } else {
            error_log('Registration error: ' . $e->getMessage());
            setFlash('error', 'เกิดข้อผิดพลาดในการบันทึกข้อมูล');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><title>สมัครสมาชิก</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container" style="max-width: 500px; margin-top: 50px;">
<div class="card">
<h2>สมัครสมาชิก</h2>
<?php echo getFlash(); ?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?php echo e($_SESSION['csrf_token']); ?>">
<input type="text" name="fullname" placeholder="ชื่อ-นามสกุล (Full Name)" required maxlength="100">
<input type="text" name="username" placeholder="Username" required maxlength="50">
<input type="password" name="password" placeholder="Password" required minlength="8">
<p style="font-size: 14px; color: #666;">* สิทธิ์การใช้งานเริ่มต้นจะเป็นบุคคลทั่วไป (User)</p>
<button type="submit" class="btn" style="width: 100%;">สมัคร (Register)</button>
<div style="margin-top: 15px; text-align: center;"><a href="login.php">กลับไปหน้าเข้าสู่ระบบ</a></div>
</form>
</div>
</div>
</body>
</html>